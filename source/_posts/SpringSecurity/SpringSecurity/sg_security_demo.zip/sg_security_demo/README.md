# sg_security_demo

电脑中安装过npm环境后

在sg_security_demo目录下执行npm install下载依赖

下载完后执行npm run serve启动项目

