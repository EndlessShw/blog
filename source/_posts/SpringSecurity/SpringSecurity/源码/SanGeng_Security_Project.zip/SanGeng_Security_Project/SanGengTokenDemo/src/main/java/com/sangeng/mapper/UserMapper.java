package com.sangeng.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.sangeng.domain.User;

public interface UserMapper extends BaseMapper<User> {
}
